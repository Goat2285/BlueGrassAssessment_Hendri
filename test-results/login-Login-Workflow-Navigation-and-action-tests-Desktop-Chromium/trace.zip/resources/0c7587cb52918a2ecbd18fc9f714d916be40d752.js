"use strict";
(globalThis["webpackChunk_minimal_material_kit_react"] = globalThis["webpackChunk_minimal_material_kit_react"] || []).push([["src_pages_RegisterPage_tsx"],{

/***/ "./src/components/confirm-dialog/ConfirmDialog.tsx":
/*!*********************************************************!*\
  !*** ./src/components/confirm-dialog/ConfirmDialog.tsx ***!
  \*********************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ConfirmDialog)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Dialog/Dialog.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/IconButton/IconButton.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/DialogTitle/DialogTitle.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/DialogContent/DialogContent.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/DialogActions/DialogActions.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Button/Button.js");
/* harmony import */ var _iconify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../iconify */ "./src/components/iconify/index.ts");
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./style */ "./src/components/confirm-dialog/style.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\components\\confirm-dialog\\ConfirmDialog.tsx";
// @mui



//

// ----------------------------------------------------------------------

function ConfirmDialog(_ref) {
  let {
    title,
    content,
    action,
    open,
    hideCloseBtn,
    onClose,
    ...other
  } = _ref;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
    fullWidth: true,
    maxWidth: "xs",
    open: open,
    onClose: onClose,
    ...other,
    children: [!hideCloseBtn ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_style__WEBPACK_IMPORTED_MODULE_1__.StyledButtonHolder, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
        onClick: onClose,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_iconify__WEBPACK_IMPORTED_MODULE_0__["default"], {
          icon: "eva:close-fill"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 9
    }, this) : null, title ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
      sx: {
        pb: 2
      },
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 16
    }, this) : null, content && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
      sx: {
        typography: 'body2'
      },
      children: [" ", content, " "]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 19
    }, this), action ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
      children: [action, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        variant: "outlined",
        color: "inherit",
        onClick: onClose,
        children: "Cancel"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 9
    }, this) : null]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 27,
    columnNumber: 5
  }, this);
}
_c = ConfirmDialog;
var _c;
__webpack_require__.$Refresh$.register(_c, "ConfirmDialog");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/components/confirm-dialog/index.ts":
/*!************************************************!*\
  !*** ./src/components/confirm-dialog/index.ts ***!
  \************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _ConfirmDialog__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _ConfirmDialog__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ConfirmDialog */ "./src/components/confirm-dialog/ConfirmDialog.tsx");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");



const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/components/confirm-dialog/style.ts":
/*!************************************************!*\
  !*** ./src/components/confirm-dialog/style.ts ***!
  \************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StyledButtonHolder": () => (/* binding */ StyledButtonHolder)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/material/styles */ "./node_modules/@mui/material/esm/styles/styled.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");


const StyledButtonHolder = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__["default"])('div')(() => ({
  width: 40,
  height: 40,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  position: 'absolute',
  top: 0,
  right: 0
}));

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/components/stepper/stepper.tsx":
/*!********************************************!*\
  !*** ./src/components/stepper/stepper.tsx ***!
  \********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LABELWIDTH": () => (/* binding */ LABELWIDTH),
/* harmony export */   "SIDEPADDING": () => (/* binding */ SIDEPADDING),
/* harmony export */   "default": () => (/* binding */ Stepper)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Box/Box.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Stack/Stack.js");
/* harmony import */ var _mui_icons_material_Check__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/icons-material/Check */ "./node_modules/@mui/icons-material/Check.js");
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./styles */ "./src/components/stepper/styles.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\components\\stepper\\stepper.tsx";


// Styles


const LABELWIDTH = 240;
const SIDEPADDING = 100;
function Stepper(_ref) {
  let {
    currentStep,
    steps
  } = _ref;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_0__.StyledStepper, {
    sx: {
      maxWidth: steps.length * LABELWIDTH + SIDEPADDING * 2
    },
    children: steps.map((entry, index) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
      sx: {
        flex: index !== 0 ? 1 : 0,
        position: 'relative'
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
        direction: "row",
        alignItems: "center",
        sx: {
          margin: '0 !important',
          flex: index !== 0 ? 1 : 0
        },
        children: [index !== 0 ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_0__.StyledStepLine, {
          sx: {
            backgroundColor: currentStep >= entry.step ? 'primary.main' : 'grey.300'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 15
        }, this) : null, currentStep <= entry.step ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_0__.StyledDot, {
          sx: {
            backgroundColor: currentStep >= entry.step ? 'primary.main' : 'grey.300'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 15
        }, this) : null, currentStep > entry.step ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_mui_icons_material_Check__WEBPACK_IMPORTED_MODULE_4__["default"], {
          color: "primary",
          sx: {
            margin: '8px'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 41
        }, this) : null]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 11
      }, this), entry.tickLabel ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_0__.StyledStepperLabel, {
        children: entry.tickLabel
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 30
      }, this) : null]
    }, entry.key, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 9
    }, this))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 5
  }, this);
}
_c = Stepper;
var _c;
__webpack_require__.$Refresh$.register(_c, "Stepper");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/components/stepper/styles.ts":
/*!******************************************!*\
  !*** ./src/components/stepper/styles.ts ***!
  \******************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StyledDot": () => (/* binding */ StyledDot),
/* harmony export */   "StyledStepLine": () => (/* binding */ StyledStepLine),
/* harmony export */   "StyledStepper": () => (/* binding */ StyledStepper),
/* harmony export */   "StyledStepperLabel": () => (/* binding */ StyledStepperLabel)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material/styles */ "./node_modules/@mui/material/esm/styles/styled.js");
/* harmony import */ var _stepper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./stepper */ "./src/components/stepper/stepper.tsx");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");



const StyledDot = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__["default"])('div')(_ref => {
  let {
    theme
  } = _ref;
  return {
    width: '8px',
    height: '8px',
    margin: 16,
    borderRadius: '50%',
    backgroundColor: theme.palette.primary.main
  };
});
const StyledStepLine = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__["default"])('div')(() => ({
  height: '2px',
  flex: 1
}));
const StyledStepper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__["default"])('div')(_ref2 => {
  let {
    theme
  } = _ref2;
  return {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    width: '100%',
    paddingBottom: '38px',
    paddingLeft: _stepper__WEBPACK_IMPORTED_MODULE_0__.SIDEPADDING,
    paddingRight: _stepper__WEBPACK_IMPORTED_MODULE_0__.SIDEPADDING,
    [theme.breakpoints.down('sm')]: {
      paddingLeft: 0,
      paddingRight: 0
    }
  };
});
const StyledStepperLabel = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__["default"])('p')(_ref3 => {
  let {
    theme
  } = _ref3;
  return {
    position: 'absolute',
    right: '15px',
    transform: 'translateX(50%)',
    marginBottom: 0,
    marginTop: '8px',
    fontSize: "14px",
    lineHeight: "22px",
    letterSpacing: 0,
    textAlign: 'center',
    width: _stepper__WEBPACK_IMPORTED_MODULE_0__.LABELWIDTH,
    [theme.breakpoints.down('sm')]: {
      display: 'none'
    }
  };
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/hooks/api/auth/useGetPatientInfo.ts":
/*!*************************************************!*\
  !*** ./src/hooks/api/auth/useGetPatientInfo.ts ***!
  \*************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useGetPatientInfo": () => (/* binding */ useGetPatientInfo)
/* harmony export */ });
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tanstack/react-query */ "./node_modules/@tanstack/react-query/build/lib/useQuery.mjs");
/* harmony import */ var src_services_api_auth_getPatientInfo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/services/api/auth/getPatientInfo */ "./src/services/api/auth/getPatientInfo.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _s = __webpack_require__.$Refresh$.signature();


const useGetPatientInfo = (validData, queryOptions) => {
  _s();
  return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)(['getPatientInfo'], () => (0,src_services_api_auth_getPatientInfo__WEBPACK_IMPORTED_MODULE_0__.getPatientInfo)(validData), queryOptions);
};
_s(useGetPatientInfo, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function () {
  return [_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery];
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/hooks/api/auth/usePostPartnerDetails.ts":
/*!*****************************************************!*\
  !*** ./src/hooks/api/auth/usePostPartnerDetails.ts ***!
  \*****************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "usePostPartnerDetails": () => (/* binding */ usePostPartnerDetails)
/* harmony export */ });
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tanstack/react-query */ "./node_modules/@tanstack/react-query/build/lib/useMutation.mjs");
/* harmony import */ var src_services_api_auth_postPartnerDetails__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/services/api/auth/postPartnerDetails */ "./src/services/api/auth/postPartnerDetails.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _s = __webpack_require__.$Refresh$.signature();


const usePostPartnerDetails = queryOptions => {
  _s();
  return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(['postPartnerDetails'], src_services_api_auth_postPartnerDetails__WEBPACK_IMPORTED_MODULE_0__.postPartnerDetails, queryOptions);
};
_s(usePostPartnerDetails, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function () {
  return [_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation];
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/hooks/api/auth/usePostPersonalDetails.ts":
/*!******************************************************!*\
  !*** ./src/hooks/api/auth/usePostPersonalDetails.ts ***!
  \******************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "usePostPersonalDetails": () => (/* binding */ usePostPersonalDetails)
/* harmony export */ });
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tanstack/react-query */ "./node_modules/@tanstack/react-query/build/lib/useMutation.mjs");
/* harmony import */ var src_services_api_auth_postPersonalDetails__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/services/api/auth/postPersonalDetails */ "./src/services/api/auth/postPersonalDetails.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _s = __webpack_require__.$Refresh$.signature();


const usePostPersonalDetails = queryOptions => {
  _s();
  return (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(['postPersonalDetails'], src_services_api_auth_postPersonalDetails__WEBPACK_IMPORTED_MODULE_0__.postPersonalDetails, queryOptions);
};
_s(usePostPersonalDetails, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function () {
  return [_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation];
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/pages/RegisterPage.tsx":
/*!************************************!*\
  !*** ./src/pages/RegisterPage.tsx ***!
  \************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var react_helmet_async__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-helmet-async */ "./node_modules/react-helmet-async/lib/index.module.js");
/* harmony import */ var _sections_register__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../sections/register */ "./src/sections/register/index.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\pages\\RegisterPage.tsx";



// ----------------------------------------------------------------------


function RegisterPage() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_helmet_async__WEBPACK_IMPORTED_MODULE_0__.Helmet, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("title", {
        children: "Register"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_sections_register__WEBPACK_IMPORTED_MODULE_1__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}
_c = RegisterPage;
var _c;
__webpack_require__.$Refresh$.register(_c, "RegisterPage");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/sections/register/CompleteRegistration.tsx":
/*!********************************************************!*\
  !*** ./src/sections/register/CompleteRegistration.tsx ***!
  \********************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CompleteRegistration)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Stack/Stack.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Typography/Typography.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Button/Button.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/dist/index.js");
/* harmony import */ var src_components_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/components/image */ "./src/components/image/index.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\sections\\register\\CompleteRegistration.tsx",
  _s = __webpack_require__.$Refresh$.signature();





function CompleteRegistration(_ref) {
  _s();
  let {
    onClose
  } = _ref;
  const navigate = (0,react_router__WEBPACK_IMPORTED_MODULE_3__.useNavigate)();
  const getURLValues = () => {
    var _params$get, _params$get2;
    const params = new URLSearchParams(window.location.search);
    const token = (_params$get = params.get('t')) === null || _params$get === void 0 ? void 0 : _params$get.replace(/ /g, '+');
    const member = (_params$get2 = params.get('m')) === null || _params$get2 === void 0 ? void 0 : _params$get2.replace(/ /g, '+');
    if (!token || !member) {
      return {
        userId: 'Unknown',
        token: 'Unknown'
      };
    }
    return {
      userId: member,
      token: token
    };
  };
  const userDetails = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => getURLValues(), []);
  const handleComplete = () => {
    onClose();
    navigate(`/auth/createpassword/?t=${userDetails.token}&m=${userDetails.userId}`);
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
    direction: "column",
    alignItems: "center",
    sx: {
      px: 3
    },
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(src_components_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
      disabledEffect: true,
      visibleByDefault: true,
      alt: "My fertility journey - Happy family with a child",
      src: '/assets/images/illustrations/illustration_empty_content.svg',
      sx: {
        width: 128
      },
      objectFit: 'contain'
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
      variant: "h4",
      sx: {
        mt: '20px',
        mb: 2
      },
      children: "Application Complete!"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
      variant: "body1",
      sx: {
        textAlign: 'center'
      },
      children: "Thank you for taking this journey with us. We understand the sensitive and confidential nature of this journey and undertake to be with you every step of the way, to help you navigate both the legal and practical issues involved in your journey."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
      variant: "body1",
      sx: {
        textAlign: 'center',
        mt: 2
      },
      children: "You will be redirected to a screen where you can set your password"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
      variant: "contained",
      fullWidth: true,
      size: 'large',
      sx: {
        mt: 5
      },
      onClick: handleComplete,
      children: "Set up Password"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 38,
    columnNumber: 5
  }, this);
}
_s(CompleteRegistration, "Y+P5UtRMUsyBGDSB9BvamY1ehW0=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_3__.useNavigate];
});
_c = CompleteRegistration;
var _c;
__webpack_require__.$Refresh$.register(_c, "CompleteRegistration");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/sections/register/IncludedInPrice.tsx":
/*!***************************************************!*\
  !*** ./src/sections/register/IncludedInPrice.tsx ***!
  \***************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ IncludedInPrice)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Stack/Stack.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Typography/Typography.js");
/* harmony import */ var _mui_icons_material_Check__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/Check */ "./node_modules/@mui/icons-material/Check.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\sections\\register\\IncludedInPrice.tsx";



function IncludedInPrice(_ref) {
  let {
    title
  } = _ref;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
    direction: "row",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_mui_icons_material_Check__WEBPACK_IMPORTED_MODULE_2__["default"], {
      color: "primary"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
      variant: "body1",
      sx: {
        ml: '12px'
      },
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }, this);
}
_c = IncludedInPrice;
var _c;
__webpack_require__.$Refresh$.register(_c, "IncludedInPrice");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/sections/register/index.tsx":
/*!*****************************************!*\
  !*** ./src/sections/register/index.tsx ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Register)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Stack/Stack.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Typography/Typography.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Box/Box.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _theme_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../theme/palette */ "./src/theme/palette.ts");
/* harmony import */ var _stepData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stepData */ "./src/sections/register/stepData.ts");
/* harmony import */ var _components_stepper_stepper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/stepper/stepper */ "./src/components/stepper/stepper.tsx");
/* harmony import */ var _step1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./step1 */ "./src/sections/register/step1.tsx");
/* harmony import */ var _step2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./step2 */ "./src/sections/register/step2.tsx");
/* harmony import */ var _step3__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./step3 */ "./src/sections/register/step3.tsx");
/* harmony import */ var src_hooks_api_auth_useGetPatientInfo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/hooks/api/auth/useGetPatientInfo */ "./src/hooks/api/auth/useGetPatientInfo.ts");
/* harmony import */ var src_components_loading_screen__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/components/loading-screen */ "./src/components/loading-screen/index.ts");
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @tanstack/react-query */ "./node_modules/@tanstack/react-query/build/lib/QueryClientProvider.mjs");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\sections\\register\\index.tsx",
  _s = __webpack_require__.$Refresh$.signature();













function Register() {
  _s();
  const [currentStep, setCurrentStep] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_10__.useQueryClient)();
  const getURLValues = () => {
    var _params$get, _params$get2;
    const params = new URLSearchParams(window.location.search);
    const token = (_params$get = params.get('t')) === null || _params$get === void 0 ? void 0 : _params$get.replace(/ /g, '+');
    const member = (_params$get2 = params.get('m')) === null || _params$get2 === void 0 ? void 0 : _params$get2.replace(/ /g, '+');
    if (!token || !member) {
      return {
        userId: 'Unknown',
        token: 'Unknown'
      };
    }
    return {
      userId: member,
      token: token
    };
  };
  const userDetails = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => getURLValues(), []);
  const {
    data: patientInfo,
    isLoading
  } = (0,src_hooks_api_auth_useGetPatientInfo__WEBPACK_IMPORTED_MODULE_7__.useGetPatientInfo)({
    memberKey: userDetails.userId,
    token: userDetails.token
  });
  const refetch = () => {
    queryClient.refetchQueries(['getPatientInfo']);
  };
  if (isLoading) return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(src_components_loading_screen__WEBPACK_IMPORTED_MODULE_8__["default"], {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 47,
    columnNumber: 25
  }, this);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
    sx: {
      display: 'flex',
      flexDirection: 'center',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 1,
      width: '100%',
      py: '100px'
    },
    children: [_stepData__WEBPACK_IMPORTED_MODULE_2__["default"][currentStep].tickLabel || _stepData__WEBPACK_IMPORTED_MODULE_2__["default"][currentStep].headerTitle ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
        variant: "h3",
        dangerouslySetInnerHTML: {
          __html: _stepData__WEBPACK_IMPORTED_MODULE_2__["default"][currentStep].headerTitle ? _stepData__WEBPACK_IMPORTED_MODULE_2__["default"][currentStep].headerTitle : _stepData__WEBPACK_IMPORTED_MODULE_2__["default"][currentStep].tickLabel
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
        m: 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 11
      }, this)]
    }, void 0, true) : null, _stepData__WEBPACK_IMPORTED_MODULE_2__["default"][currentStep].headerDescription ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
        variant: "body1",
        sx: {
          textAlign: 'center',
          color: _theme_palette__WEBPACK_IMPORTED_MODULE_1__.GREYS.grey3
        },
        dangerouslySetInnerHTML: {
          __html: _stepData__WEBPACK_IMPORTED_MODULE_2__["default"][currentStep].headerDescription
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
        m: 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 11
      }, this)]
    }, void 0, true) : null, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_components_stepper_stepper__WEBPACK_IMPORTED_MODULE_3__["default"], {
      currentStep: currentStep,
      steps: _stepData__WEBPACK_IMPORTED_MODULE_2__["default"]
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
      m: 2
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 85,
      columnNumber: 7
    }, this), currentStep === 0 ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_step1__WEBPACK_IMPORTED_MODULE_4__["default"], {
      setCurrentStep: setCurrentStep,
      firstName: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.firstName,
      lastName: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.lastName,
      email: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.email,
      contactNumber: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.contactNumber,
      nationality: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.nationality,
      idOrPassport: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.idOrPassport,
      address: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.address,
      dateOfBirth: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.dateOfBirth,
      memberKey: userDetails.userId,
      token: userDetails.token,
      refetch: refetch
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 9
    }, this) : null, currentStep === 1 ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_step2__WEBPACK_IMPORTED_MODULE_5__["default"], {
      setCurrentStep: setCurrentStep,
      firstName: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.partnerFirstName,
      lastName: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.partnerLastName,
      email: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.partnerEmail,
      contactNumber: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.partnerContactNumber,
      nationality: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.partnerNationality,
      idOrPassport: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.partnerIdOrPassport,
      address: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.partnerAddress,
      dateOfBirth: patientInfo === null || patientInfo === void 0 ? void 0 : patientInfo.partnerDateOfBirth,
      memberKey: userDetails.userId,
      token: userDetails.token,
      refetch: refetch
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 103,
      columnNumber: 9
    }, this) : null, currentStep === 2 ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(_step3__WEBPACK_IMPORTED_MODULE_6__["default"], {
      setCurrentStep: setCurrentStep,
      refetch: refetch
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 118,
      columnNumber: 28
    }, this) : null]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 50,
    columnNumber: 5
  }, this);
}
_s(Register, "lYjGuLdIbSJidEfvBwueWZkcOYs=", false, function () {
  return [_tanstack_react_query__WEBPACK_IMPORTED_MODULE_10__.useQueryClient, src_hooks_api_auth_useGetPatientInfo__WEBPACK_IMPORTED_MODULE_7__.useGetPatientInfo];
});
_c = Register;
var _c;
__webpack_require__.$Refresh$.register(_c, "Register");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/sections/register/step1.tsx":
/*!*****************************************!*\
  !*** ./src/sections/register/step1.tsx ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RegisterStep1)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! yup */ "./node_modules/yup/es/index.js");
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.mjs");
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @hookform/resolvers/yup */ "./node_modules/@hookform/resolvers/yup/dist/yup.mjs");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Stack/Stack.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Box/Box.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Button/Button.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router/dist/index.js");
/* harmony import */ var _components_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/hook-form */ "./src/components/hook-form/index.ts");
/* harmony import */ var _components_snackbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/snackbar */ "./src/components/snackbar/index.ts");
/* harmony import */ var src_hooks_api_auth_usePostPersonalDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/hooks/api/auth/usePostPersonalDetails */ "./src/hooks/api/auth/usePostPersonalDetails.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\sections\\register\\step1.tsx",
  _s = __webpack_require__.$Refresh$.signature();









const southAfricanIdInfo = __webpack_require__(/*! south-african-id-info */ "./node_modules/south-african-id-info/index.js");
function RegisterStep1(_ref) {
  _s();
  let {
    setCurrentStep,
    firstName,
    lastName,
    email,
    contactNumber,
    nationality,
    idOrPassport,
    address,
    dateOfBirth,
    memberKey,
    token,
    refetch
  } = _ref;
  const navigate = (0,react_router_dom__WEBPACK_IMPORTED_MODULE_6__.useNavigate)();
  const phoneRegex = /^\+[1-9]{1}[0-9 | \s]{3,14}$/;
  const maxDate = new Date();
  const Step1Schema = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    firstName: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('First name is required'),
    lastName: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('Last name is required'),
    // email: Yup.string().email('Email must be a valid email address').required('Email is required'),
    contactNumber: yup__WEBPACK_IMPORTED_MODULE_0__.string().trim().matches(phoneRegex, 'Please use the following format: +27 72 000 0000').required('Contact number is required'),
    nationality: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('Nationality is required'),
    idOrPassport: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('nationality', {
      is: 'South African',
      then: yup__WEBPACK_IMPORTED_MODULE_0__.string().test('validator-custom-name', (value, _ref2) => {
        let {
          createError,
          path
        } = _ref2;
        if (value && southAfricanIdInfo(value).valid === false) return createError({
          path,
          message: 'Please neter a valid SA ID number'
        });else return true;
      }).required('ID or Passport number is required'),
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('ID or Passport number is required')
    }),
    address: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('Address is required'),
    dateOfBirth: yup__WEBPACK_IMPORTED_MODULE_0__.date().required('Date of birth is required').max(maxDate, 'Date of birth needs to be in the past').nullable(true)
  });
  const {
    enqueueSnackbar
  } = (0,_components_snackbar__WEBPACK_IMPORTED_MODULE_3__.useSnackbar)();
  const {
    mutate: postSubmit
  } = (0,src_hooks_api_auth_usePostPersonalDetails__WEBPACK_IMPORTED_MODULE_4__.usePostPersonalDetails)({
    onSuccess: () => {
      enqueueSnackbar('Personal details has been added!');
      refetch();
      setCurrentStep(1);
    },
    onError: () => {
      enqueueSnackbar('Error, personal details not added!', {
        variant: 'error'
      });
    }
  });
  const defaultValues = {
    firstName,
    lastName,
    email,
    contactNumber,
    nationality,
    idOrPassport,
    address,
    dateOfBirth: idOrPassport ? dateOfBirth : ''
  };
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__.yupResolver)(Step1Schema),
    defaultValues
  });
  const {
    handleSubmit
  } = methods;
  const onSubmit = data => {
    const postData = Object.assign(data, {
      memberKey,
      token,
      dateOfBirth: new Date(data.dateOfBirth).toISOString().substring(0, 10)
    });
    postSubmit(postData);
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
    direction: 'column',
    alignItems: "stetch",
    sx: {
      width: '100%',
      maxWidth: 944
    },
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__["default"], {
      methods: methods,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "firstName",
          label: "First Name",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 118,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "lastName",
          label: "Last Name",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 123,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "contactNumber",
          label: "Contact Number",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 136,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 129,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFSelect, {
          name: "nationality",
          label: "Nationality",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          variant: 'outlined',
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("option", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 149,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("option", {
            value: 'South African',
            children: "South African"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 150,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("option", {
            value: 'Zimbabwean',
            children: "Zimbabwean"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 151,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 143,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "idOrPassport",
          label: "ID / Passport Number",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 153,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 142,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "address",
          label: "Address",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 160,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFDatePicker, {
          name: "dateOfBirth",
          label: "Date of Birth",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 165,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 159,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 116,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
      m: 2
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 173,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
      direction: 'row',
      justifyContent: 'flex-end',
      m: 1,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
        variant: "text",
        onClick: () => {
          navigate(-1);
        },
        size: 'large',
        children: "Back"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 175,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
        m: 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 184,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
        variant: "contained",
        onClick: handleSubmit(onSubmit),
        size: 'large',
        children: "Next"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 185,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 174,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 115,
    columnNumber: 5
  }, this);
}
_s(RegisterStep1, "WrX/SoSgtYxl9e926zx9hVP1efY=", false, function () {
  return [react_router_dom__WEBPACK_IMPORTED_MODULE_6__.useNavigate, _components_snackbar__WEBPACK_IMPORTED_MODULE_3__.useSnackbar, src_hooks_api_auth_usePostPersonalDetails__WEBPACK_IMPORTED_MODULE_4__.usePostPersonalDetails, react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm];
});
_c = RegisterStep1;
var _c;
__webpack_require__.$Refresh$.register(_c, "RegisterStep1");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/sections/register/step2.tsx":
/*!*****************************************!*\
  !*** ./src/sections/register/step2.tsx ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RegisterStep2)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! yup */ "./node_modules/yup/es/index.js");
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.mjs");
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @hookform/resolvers/yup */ "./node_modules/@hookform/resolvers/yup/dist/yup.mjs");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Stack/Stack.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Box/Box.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Button/Button.js");
/* harmony import */ var _components_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/hook-form */ "./src/components/hook-form/index.ts");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_snackbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/snackbar */ "./src/components/snackbar/index.ts");
/* harmony import */ var src_hooks_api_auth_usePostPartnerDetails__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/hooks/api/auth/usePostPartnerDetails */ "./src/hooks/api/auth/usePostPartnerDetails.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\sections\\register\\step2.tsx",
  _s = __webpack_require__.$Refresh$.signature();









const southAfricanIdInfo = __webpack_require__(/*! south-african-id-info */ "./node_modules/south-african-id-info/index.js");
function RegisterStep2(_ref) {
  _s();
  let {
    setCurrentStep,
    firstName,
    lastName,
    email,
    contactNumber,
    nationality,
    idOrPassport,
    address,
    dateOfBirth,
    memberKey,
    token,
    refetch
  } = _ref;
  const phoneRegex = /^\+[1-9]{1}[0-9 | \s]{3,14}$/;
  const maxDate = new Date();
  const Step2Schema = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    hasnopartner: yup__WEBPACK_IMPORTED_MODULE_0__.boolean(),
    firstName: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('hasnopartner', {
      is: true,
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('First name is required')
    }),
    lastName: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('hasnopartner', {
      is: true,
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('Last name is required')
    }),
    email: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('hasnopartner', {
      is: true,
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().email('Email must be a valid email address').required('Email is required')
    }),
    contactNumber: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('hasnopartner', {
      is: true,
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().trim().matches(phoneRegex, 'Please use the following format: +27 72 000 0000').required('Contact number is required')
    }),
    nationality: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('hasnopartner', {
      is: true,
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('Nationality is required')
    }),
    idOrPassport: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('hasnopartner', {
      is: true,
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('nationality', {
        is: 'South African',
        then: yup__WEBPACK_IMPORTED_MODULE_0__.string().test('validator-custom-name', (value, _ref2) => {
          let {
            createError,
            path
          } = _ref2;
          if (value && southAfricanIdInfo(value).valid === false) return createError({
            path,
            message: 'Please neter a valid SA ID number'
          });else return true;
        }).required('ID or Passport number is required'),
        otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('ID or Passport number is required')
      })
    }),
    address: yup__WEBPACK_IMPORTED_MODULE_0__.string().when('hasnopartner', {
      is: true,
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.string().required('Address is required')
    }),
    dateOfBirth: yup__WEBPACK_IMPORTED_MODULE_0__.mixed().when('hasnopartner', {
      is: true,
      then: yup__WEBPACK_IMPORTED_MODULE_0__.string().nullable(true),
      otherwise: yup__WEBPACK_IMPORTED_MODULE_0__.date().required('Date of birth is required').max(maxDate, 'Date of birth needs to be in the past').nullable(true)
    })
  });
  const {
    enqueueSnackbar
  } = (0,_components_snackbar__WEBPACK_IMPORTED_MODULE_4__.useSnackbar)();
  const {
    mutate: postSubmit
  } = (0,src_hooks_api_auth_usePostPartnerDetails__WEBPACK_IMPORTED_MODULE_5__.usePostPartnerDetails)({
    onSuccess: () => {
      enqueueSnackbar('Partner details has been added!');
      refetch();
      setCurrentStep(2);
    },
    onError: () => {
      enqueueSnackbar('Error, partner details not added!', {
        variant: 'error'
      });
    }
  });
  const defaultValues = {
    firstName: firstName || '',
    lastName: lastName || '',
    email: email || '',
    contactNumber: contactNumber || '',
    nationality: nationality || '',
    idOrPassport: idOrPassport || '',
    address: address || '',
    dateOfBirth: idOrPassport ? dateOfBirth : '',
    hasnopartner: firstName ? false : true
  };
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_1__.yupResolver)(Step2Schema),
    defaultValues
  });
  const {
    handleSubmit,
    clearErrors,
    watch,
    resetField
  } = methods;
  const hasNoPartnerWatcher = watch('hasnopartner', false);
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (hasNoPartnerWatcher) {
      clearErrors();
    }
  }, [clearErrors, hasNoPartnerWatcher, resetField]);
  const onSubmit = data => {
    delete data.hasnopartner;
    const postData = Object.assign(data, {
      memberKey,
      token,
      dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth).toISOString().substring(0, 10) : '2022-12-23T14:01:23.635Z',
      hasPartner: !hasNoPartnerWatcher
    });
    console.log(postData);
    postSubmit(postData);
  };
  const prevStepHandler = () => {
    setCurrentStep(0);
    refetch();
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
    direction: 'column',
    alignItems: "stetch",
    sx: {
      width: '100%',
      maxWidth: 944
    },
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__["default"], {
      methods: methods,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "firstName",
          label: "First Name",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          disabled: hasNoPartnerWatcher
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 171,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "lastName",
          label: "Last Name",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          disabled: hasNoPartnerWatcher
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 177,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 170,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "email",
          label: "Email",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          disabled: hasNoPartnerWatcher
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "contactNumber",
          label: "Contact Number",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          disabled: hasNoPartnerWatcher
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 191,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 184,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFSelect, {
          name: "nationality",
          label: "Nationality",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          variant: 'outlined',
          disabled: hasNoPartnerWatcher,
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("option", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 206,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("option", {
            value: 'South African',
            children: "South African"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 207,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("option", {
            value: 'Zimbabwean',
            children: "Zimbabwean"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 208,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 199,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "idOrPassport",
          label: "ID / Passport Number",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          disabled: hasNoPartnerWatcher
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 210,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 198,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFTextField, {
          name: "address",
          label: "Address",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          disabled: hasNoPartnerWatcher
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 218,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFDatePicker, {
          name: "dateOfBirth",
          label: "Date of Birth",
          sx: {
            maxWidth: 448,
            margin: '12px !important'
          },
          disabled: hasNoPartnerWatcher
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 224,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 217,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
        spacing: 3,
        direction: 'row',
        flexWrap: 'wrap',
        justifyContent: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_2__.RHFCheckbox, {
          name: "hasnopartner",
          label: "I have no partner",
          sx: {
            maxWidth: 448,
            margin: '12px !important',
            width: '100%'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 232,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
          sx: {
            maxWidth: 448,
            margin: '12px !important',
            width: '100%'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 237,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 231,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
      m: 2
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 241,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
      direction: 'row',
      justifyContent: 'flex-end',
      m: 1,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
        variant: "text",
        onClick: () => {
          prevStepHandler();
        },
        size: 'large',
        children: "Back"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 243,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
        m: 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 252,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
        variant: "contained",
        onClick: handleSubmit(onSubmit),
        size: 'large',
        children: "Next"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 253,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 242,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 168,
    columnNumber: 5
  }, this);
}
_s(RegisterStep2, "jY08XaPsAADp7Ra1IIDBCr2qqSo=", false, function () {
  return [_components_snackbar__WEBPACK_IMPORTED_MODULE_4__.useSnackbar, src_hooks_api_auth_usePostPartnerDetails__WEBPACK_IMPORTED_MODULE_5__.usePostPartnerDetails, react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm];
});
_c = RegisterStep2;
var _c;
__webpack_require__.$Refresh$.register(_c, "RegisterStep2");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/sections/register/step3.tsx":
/*!*****************************************!*\
  !*** ./src/sections/register/step3.tsx ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RegisterStep3)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Grid/Grid.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Card/Card.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Typography/Typography.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Stack/Stack.js");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/esm/Button/Button.js");
/* harmony import */ var _components_hook_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../components/hook-form */ "./src/components/hook-form/index.ts");
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.mjs");
/* harmony import */ var _IncludedInPrice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./IncludedInPrice */ "./src/sections/register/IncludedInPrice.tsx");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_components_confirm_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/components/confirm-dialog */ "./src/components/confirm-dialog/index.ts");
/* harmony import */ var _CompleteRegistration__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CompleteRegistration */ "./src/sections/register/CompleteRegistration.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\admin\\Documents\\BG\\bg_qa_engineering_technical_assessment\\src\\sections\\register\\step3.tsx",
  _s = __webpack_require__.$Refresh$.signature();









const INCLUDED_IN_PROCE = ['Access the My Journey Education Library', 'Read and download treatment Fact Sheets', 'Watch and learn videos about you treatment and procedures', 'Navigate and electronically sign the clinics consent forms'];
function RegisterStep3(_ref) {
  _s();
  let {
    setCurrentStep,
    refetch
  } = _ref;
  const [isOpenDialog, setIsOpenDialog] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const defaultValues = {
    nameOnCard: '',
    cardNumber: '',
    expiry: '',
    cvv: ''
  };
  const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useForm)({
    defaultValues
  });
  const {
    handleSubmit
  } = methods;
  const handleOpen = () => {
    setIsOpenDialog(true);
  };
  const handleClose = () => {
    setIsOpenDialog(false);
  };
  const onSubmit = data => {
    handleOpen();
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
      container: true,
      spacing: 3,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
          sx: {
            px: 4,
            py: 5,
            height: '100%'
          },
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
            variant: "overline",
            color: "primary.dark",
            sx: {
              mb: 2
            },
            children: "Subscription"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
            direction: "row",
            alignItems: "baseline",
            sx: {
              mb: 5
            },
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
              variant: "h2",
              sx: {
                fontWeight: 'fontWeightBold'
              },
              children: "R99"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 61,
              columnNumber: 15
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
              variant: "body2",
              sx: {
                fontWeight: 500
              },
              children: "/ once off"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 64,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 60,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
            direction: "column",
            spacing: 2,
            children: INCLUDED_IN_PROCE.map(title => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_IncludedInPrice__WEBPACK_IMPORTED_MODULE_1__["default"], {
              title: title
            }, title, false, {
              fileName: _jsxFileName,
              lineNumber: 70,
              columnNumber: 17
            }, this))
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
          sx: {
            px: 4,
            py: 5,
            height: '100%'
          },
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
            variant: "h5",
            children: "Payment Details"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 77,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_0__["default"], {
            methods: methods,
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
              container: true,
              sx: {
                pt: 3
              },
              spacing: 3,
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                item: true,
                xs: 12,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_0__.RHFTextField, {
                  name: "nameOnCard",
                  label: "Name on card"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 81,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                item: true,
                xs: 12,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_0__.RHFTextField, {
                  name: "cardNumber",
                  label: "Card number"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 84,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 83,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                item: true,
                xs: 12,
                md: 6,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_0__.RHFTextField, {
                  name: "expiry",
                  label: "Expiry (MM/YY)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 87,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                item: true,
                xs: 12,
                md: 6,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_hook_form__WEBPACK_IMPORTED_MODULE_0__.RHFTextField, {
                  name: "cvv",
                  label: "CVV"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 90,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 89,
                columnNumber: 17
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                item: true,
                xs: 12,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                  fullWidth: true,
                  variant: "contained",
                  onClick: handleSubmit(onSubmit),
                  size: 'large',
                  children: "Pay Now"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 93,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 92,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
      direction: "row",
      justifyContent: "flex-start",
      sx: {
        width: '100%'
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
        variant: "contained",
        onClick: () => {
          setCurrentStep(1);
          refetch();
        },
        size: 'large',
        sx: {
          mt: 3
        },
        children: "Back"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 108,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 107,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(src_components_confirm_dialog__WEBPACK_IMPORTED_MODULE_3__["default"], {
      open: isOpenDialog,
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_CompleteRegistration__WEBPACK_IMPORTED_MODULE_4__["default"], {
        onClose: handleClose
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 122,
        columnNumber: 18
      }, this),
      hideCloseBtn: true,
      sx: {
        '& .MuiDialogContent-root': {
          paddingTop: '8px !important'
        },
        '& .MuiPaper-root': {
          maxWidth: 528,
          padding: '28px 24px 56px',
          '& .MuiDialogContent-root': {
            padding: 0
          }
        }
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 120,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}
_s(RegisterStep3, "Qxkj8Nhj3dg+UvgziIP8hddCjnU=", false, function () {
  return [react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useForm];
});
_c = RegisterStep3;
var _c;
__webpack_require__.$Refresh$.register(_c, "RegisterStep3");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/sections/register/stepData.ts":
/*!*******************************************!*\
  !*** ./src/sections/register/stepData.ts ***!
  \*******************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

const StepperSteps = [{
  step: 0,
  tickLabel: 'Partner 1 - Information',
  headerTitle: '',
  headerDescription: 'Please enter all of your personal information below. These will be the details of the primary patient',
  key: 'registrationStep1'
}, {
  step: 1,
  tickLabel: 'Partner 2 -  Information',
  headerTitle: '',
  headerDescription: 'Please enter all of your partner’s details below. <br/> An account will also be created for your partner after signup completion.',
  key: 'registrationStep2'
}, {
  step: 2,
  tickLabel: 'Payment Information',
  headerTitle: 'Sign up to My Fertility Journey',
  headerDescription: 'My Fertility Journey will help you navigate your fertility journey, by assisting you with all necessary information about <br/> your procedures and upcoming treatment, through the Education Library. <br/> My Fertility Journey will also assist you with the signing of the medical consents that you are required to sign.',
  key: 'registrationStep3'
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StepperSteps);

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/services/api/auth/getPatientInfo.ts":
/*!*************************************************!*\
  !*** ./src/services/api/auth/getPatientInfo.ts ***!
  \*************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getPatientInfo": () => (/* binding */ getPatientInfo)
/* harmony export */ });
/* harmony import */ var src_services_axiosConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/services/axiosConfig */ "./src/services/axiosConfig.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");


const getPatientInfo = async validData => {
  const {
    data
  } = await (0,src_services_axiosConfig__WEBPACK_IMPORTED_MODULE_0__.axiosRequest)('GET', `/api/Patient/SignUp?memberKey=${validData.memberKey}&token=${validData.token}`);
  return data;
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/services/api/auth/postPartnerDetails.ts":
/*!*****************************************************!*\
  !*** ./src/services/api/auth/postPartnerDetails.ts ***!
  \*****************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "postPartnerDetails": () => (/* binding */ postPartnerDetails)
/* harmony export */ });
/* harmony import */ var src_services_axiosConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/services/axiosConfig */ "./src/services/axiosConfig.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");


const postPartnerDetails = async partnerDetailsData => {
  const {
    data
  } = await (0,src_services_axiosConfig__WEBPACK_IMPORTED_MODULE_0__.axiosRequest)('POST', '/api/Patient/SignUp/PartnerDetails', {
    data: partnerDetailsData
  });
  return data;
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/services/api/auth/postPersonalDetails.ts":
/*!******************************************************!*\
  !*** ./src/services/api/auth/postPersonalDetails.ts ***!
  \******************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "postPersonalDetails": () => (/* binding */ postPersonalDetails)
/* harmony export */ });
/* harmony import */ var src_services_axiosConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/services/axiosConfig */ "./src/services/axiosConfig.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");


const postPersonalDetails = async personalDetailsData => {
  const {
    data
  } = await (0,src_services_axiosConfig__WEBPACK_IMPORTED_MODULE_0__.axiosRequest)('POST', '/api/Patient/SignUp/PersonalDetails', {
    data: personalDetailsData
  });
  return data;
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ })

}]);
//# sourceMappingURL=src_pages_RegisterPage_tsx.chunk.js.map